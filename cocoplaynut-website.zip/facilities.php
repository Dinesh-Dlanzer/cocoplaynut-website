
<?php 
  
  // Redirect browser 
  header("Location: indoor-facilities"); 
    
  exit;
  ?>