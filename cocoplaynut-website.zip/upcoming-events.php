
<?php 
  
  // Redirect browser 
  header("Location: activities"); 
    
  exit;
  ?>