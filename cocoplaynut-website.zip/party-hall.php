
<?php 
  
  // Redirect browser 
  header("Location: birthdays"); 
    
  exit;
  ?>